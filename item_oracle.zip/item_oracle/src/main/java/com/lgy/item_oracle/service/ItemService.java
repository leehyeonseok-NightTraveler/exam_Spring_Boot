package com.lgy.item_oracle.service;

import org.springframework.ui.Model;

public interface ItemService {
	public void execute(Model model);
}
