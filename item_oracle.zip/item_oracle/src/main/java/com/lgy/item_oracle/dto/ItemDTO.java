package com.lgy.item_oracle.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ItemDTO {
	private String name;
	private int price;
	private String description;
}
