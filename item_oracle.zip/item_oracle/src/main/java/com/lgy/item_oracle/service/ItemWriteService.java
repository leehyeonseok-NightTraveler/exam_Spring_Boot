package com.lgy.item_oracle.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.lgy.item_oracle.dao.ItemDAO;




public class ItemWriteService implements ItemService{
	
	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		
		String itemName = request.getParameter("name");
		String itemPrice= request.getParameter("price");
		String itemDescription = request.getParameter("description");
		
		ItemDAO dao = new ItemDAO();
		dao.write(itemName, itemPrice, itemDescription);
		
	}
}
